const rootRouter = require('./rootRouter')
const postRouter = require('./postRouter')
const commentRouter = require('./commentRouter')

const router = {
    root: rootRouter,
    post: postRouter,
    comment: commentRouter,
}

module.exports = router