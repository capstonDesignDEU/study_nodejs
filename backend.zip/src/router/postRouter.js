const express = require('express');
const { getPosting, postPosting, viewPosting} = require('../controller/postController');
const { checkLogin } = require('../middleware/authMiddleware');
const postRouter = express.Router();

postRouter.route("/posting").all(checkLogin).get(getPosting).post(postPosting);
postRouter.get("/:id([0-9a-f]{24})", viewPosting);

module.exports = postRouter;