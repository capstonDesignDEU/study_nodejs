const express = require('express');
const { postComment } = require('../controller/commentController');

const commentRouter = express.Router();

commentRouter.route("/:id([0-9a-f]{24})").post(postComment);

module.exports = commentRouter;