const express = require('express');
const { getJoin, postJoin, getLogin, getHome, postLogin } = require('../controller/userController');
const rootRouter = express.Router();

rootRouter.get("/", getHome);
rootRouter.route("/join").get(getJoin).post(postJoin);
rootRouter.route("/login").get(getLogin).post(postLogin);

module.exports = rootRouter;