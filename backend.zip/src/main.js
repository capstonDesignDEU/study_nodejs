const express = require('express');
const ejs = require('ejs');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const router = require('./router/router');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const app = express();

const store = new MongoDBStore({
    uri: process.env.DB_URL,
    collection: 'Session'
})
app.use(bodyParser.json())
app.use(express.urlencoded({extended:true}))
app.use(morgan("dev"));
app.use(session({
    secret: "sadfasdf",
    resave: false,
    saveUninitialized: true,
    store: store,
}))
app.set('view engine', 'ejs')
app.set('views', './src/views')

app.use("/public", express.static(__dirname+"/public"))
app.use("/", router.root)
app.use("/post", router.post)
app.use("/comment", router.comment)

module.exports = app;