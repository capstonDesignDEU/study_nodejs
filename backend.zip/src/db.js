const mongoose = require('mongoose');

async function dbServer() {
    try{
        await mongoose.connect(process.env.DB_URL);
        console.log("DB연결성공!")
    }catch(error){
        console.log("DB연결실패ㅠ")
    }
}
dbServer();
// const db = mongoose.connection;

// const dbHandleError = (err) => {
//     console.log('DB연결실패ㅠ')
// };

// const dbHandleConnect = () => {
//     console.log('DB연결성공!')
// };

// db.on('error', dbHandleError);
// db.once('open', dbHandleConnect)