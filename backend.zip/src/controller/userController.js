const User = require("../model/user");
const Post = require("../model/post");

exports.getHome = async (req, res) => {
    let loggedIn = false;
    if(req.session.loggedIn){
        loggedIn = true
    }
    const allPost = await Post.find({});
    
    return res.render("home", {allPost, loggedIn});
}

exports.getJoin = (req, res) => {
    return res.render("join");
}

exports.postJoin = async(req, res) => {
    const { email, password, age, sex } = req.body;
    try{
        await User.create({
            email,
            password,
            age,
            sex
        });
        return res.redirect("/login");
    }catch(error){
        return res.render("join");
    }
}

exports.getLogin = (req, res) => {
    return res.render("login");
}

exports.postLogin = async(req, res) => {
    const { email, password } = req.body;
    try{
        const userInfo = await User.findOne({email: email});
        if(!userInfo){
            return res.status(400).render("login")
        }
        if(userInfo.password === password){
            req.session.loggedIn = true;
            req.session.user = userInfo;
            return res.redirect("/")
        }else{
            return res.status(400).render("login")
        }
    }catch(error){
        console.log(error)
        return res.status(400).render("login")
    }
}