const Post = require('../model/post');

exports.viewPosting = async(req, res) => {
    const {id} = req.params;
    try{
        const post = await Post.findById(id).populate("writer").populate("comments");
        console.log(post.comments)
        return res.render("post/view", { post })
    }catch(error){
        return res.end()
    }
}

exports.getPosting = function(req, res){
    const errorMessage = null
    return res.render("post/post", {errorMessage})
}

exports.postPosting = async function(req, res){
    const { title, body } = req.body;
    const {
        user: {_id}
    } = req.session;
    try{
        await Post.create({
            title,
            body,
            writer: _id,
        })
        return res.redirect("/")
    }catch(error){
        return res.render("post/post", {errorMessage: "등록실패 DB서버에러!"})
    }
    
}

