const Comment = require('../model/comment');
const Post = require('../model/post');

exports.postComment = async (req, res) => {
    const {
        session: {user},
        body: {content},
        params: {id},
    } = req;
    try{
        const post = await Post.findById(id);
        const comment = await Comment.create({
            content,
            writer: user._id,
            post: id
        });
        console.log(comment)
        if(!post){
            return res.send('<script type="text/javascript">window.location = document.referrer; </script>');
        }
        post.comments.push(comment._id);
        post.save();
        return res.redirect(`/post/${id}`)
    }catch(error){
        return res.send('<script type="text/javascript">window.location = document.referrer; </script>');
    }
    
}

exports.editComment = async (req, res) => {

}

exports.deleteComment = async(req, res) => {
    
}