require('dotenv').config()
const db = require('./db');
const app = require('./main');

const handleListening = () => {
    console.log(`http://localhost:4000`)
}

app.listen(4000, handleListening);